UNDANGAN DIGITAL FIKRIYA ALI & AMITA RAHMA

Isi paket:
- index.html : halaman undangan
- musik.mp3  : musik Wedding Nasheed - Muhammad Al Muqit

Catatan:
Buka index.html di browser. Untuk memutar musik di HP, tekan tombol '♪ Musik'.
Untuk membuat link publik, upload seluruh isi folder ini ke layanan hosting web.
